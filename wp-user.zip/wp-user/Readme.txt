Author: Rahul
Author URL: 
Author Email: rdfullstack@gmail.com

Instructions -
## Copy pluginajax folder in wp-content/plugins/ directory.
## Login to your WordPress admin dashboard and navigate to plugins menu.
## Activate wp-user plugin.
## Add "WpUserList" shortcode to your page or post to list the user
## By clicking on the user all the user details will be display over popup